use ggez::{event, Context, ContextBuilder, GameResult};
use ggez::conf::{FullscreenType, WindowMode, WindowSetup};
use ggez::event::EventHandler;
use ggez::glam::Vec2;
use ggez::graphics::{Canvas, Color, DrawMode, DrawParam, Drawable, FontData, Mesh, PxScale, Rect, Text, TextFragment};
use ggez::input::keyboard::{Key, KeyInput};
use ggez::mint::Point2;
use ggez::winit::keyboard::NamedKey;
use lazy_static::lazy_static;
use rand::{random_range};

const TR: f32 = 18.0;
const BR: f32 = 20.0;
const DBR: f32 = BR * 2.0;
const SBR: f32 = BR * 6.0;


lazy_static! {
    static ref VALID_GUESSES: Vec<&'static str> = {
        include_str!("valid_guesses.txt")
            .lines().map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .collect() };
    static ref SOLUTIONS: Vec<&'static str> = {
        include_str!("solutions.txt")
            .lines().map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .collect() };
}

struct VirtualKeyboard {
    found_letters: String,
    correct_letters: String,
    wrong_letters: String,
    layout: KeyboardLayout,
}

#[derive(Clone)]
enum KeyboardLayout {
    Qwerty,
    Azerty,
}

impl VirtualKeyboard {
    fn new() -> Self {
        Self {
            found_letters: String::new(),
            correct_letters: String::new(),
            wrong_letters: String::new(),
            layout: KeyboardLayout::Qwerty,
        }
    }

    fn get_layout_rows(&self) -> Vec<&str> {
        match self.layout {
            KeyboardLayout::Qwerty => vec!["qwertyuiop", "asdfghjkl", "zxcvbnm"],
            KeyboardLayout::Azerty => vec!["azertyuiop", "qsdfghjklm", "wxcvbn"],
        }
    }

    fn draw(&self, canvas: &mut Canvas, ctx: &mut Context) {
        let (w, h) = ctx.gfx.drawable_size();
        let keyboard_width = w / 1.5;

        let rows = self.get_layout_rows();
        let size = keyboard_width / 10.0;

        for (row_index, row_letters) in rows.iter().enumerate() {
            let row_y = h / 2.0 + (row_index as f32 - 1.5) * size;

            let mid_point = row_letters.len() + 1 >> 1;
            let left_half = &row_letters[..mid_point];
            let right_half = &row_letters[mid_point..];

            for (col_index, ch) in left_half.chars().rev().enumerate() {
                let x = w / 2.0 - w / TR * 4.0 - col_index as f32 * size;
                self.draw_key(ctx, canvas, x, row_y, size, ch);
            }
            
            for (col_index, ch) in right_half.chars().enumerate() {
                let x = w / 2.0 + w / TR * 3.0 + col_index as f32 * size;
                self.draw_key(ctx, canvas, x, row_y, size, ch);
            }


        }
    }

    fn draw_key(&self, ctx: &mut Context, canvas: &mut Canvas, x: f32, y: f32, size: f32, ch: char) {
        let key_rect = Rect::new(x, y, size * 0.9, size * 0.9);
        let (bg_color, key_color) =
            if self.found_letters.contains(ch) { (Color::from_rgb(0, 150, 20), Color::from_rgb(150, 255, 160)) }
            else if self.correct_letters.contains(ch) { (Color::from_rgb(150, 100, 20), Color::from_rgb(255, 200, 0)) }
            else if self.wrong_letters.contains(ch) { (Color::from_rgb(22, 22, 29), Color::from_rgb(22, 22, 29)) }
            else { (Color::from_rgb(5, 7, 12), Color::WHITE) };

        let key_mesh = Mesh::new_rounded_rectangle(
            ctx, DrawMode::fill(), key_rect, size * 0.2, bg_color).unwrap();
        let letter_fragment = TextFragment::new(ch.to_uppercase().to_string())
            .color(key_color).scale(PxScale::from(size * 0.6)).font("JM");
        let letter = Text::new(letter_fragment);
        let td = letter.dimensions(ctx);
        let text_x = x + (size - td.w) / 2.0;
        let text_y = y + (size - td.h) / 2.0;
        canvas.draw(&key_mesh, DrawParam::default());
        canvas.draw(&letter, Point2 { x: text_x, y: text_y });
    }

    fn swap_layout(&mut self) {
        self.layout = match self.layout {
            KeyboardLayout::Qwerty => KeyboardLayout::Azerty,
            KeyboardLayout::Azerty => KeyboardLayout::Qwerty,
        }
    }
}

struct GameMenu {
    floating: Mesh,
    floating_stroke: Mesh,
    time: Option<f32>,
    win: Option<bool>,
}

impl GameMenu {
    fn new(ctx: &mut Context) -> Self {
        let (w, h) = ctx.gfx.drawable_size();

        let rect = Rect::new(w / 4.0, h / TR, w / 2.0, h / TR * 2.0);
        let floating = Mesh::new_rounded_rectangle(
            ctx, DrawMode::fill(), rect, w / DBR,
            Color::from_rgb(5, 7, 15)).unwrap();
        let floating_stroke = Mesh::new_rounded_rectangle(
            ctx, DrawMode::stroke(w / SBR),
            rect, w / DBR, Color::from_rgb(10, 7, 15)).unwrap();

        Self { floating, floating_stroke, time: None, win: None, }
    }

    fn draw(&self, canvas: &mut Canvas, ctx: &mut Context, solution: String) {
        let (w, h) = ctx.gfx.drawable_size();
        canvas.draw(&self.floating, Vec2::ZERO);
        canvas.draw(&self.floating_stroke, Vec2::ZERO);
        let status_text = if let Some(win) = self.win {
            if win { &format!("You Won in {:.2} seconds", self.time.unwrap()) }
            else { &format!("You missed ''{solution}''... :(") } }
            else { "Welcome! (by lygzounette)" };
        let frag = if let Some(win) = self.win {
                TextFragment::new(status_text)
                    .color(if win { Color::from_rgb(120, 250, 120) }
                    else { Color::from_rgb(220, 10, 20) })
                    .scale(PxScale::from(w / BR)).font("JM") }
            else { TextFragment::new(status_text)
                .color(Color::from_rgb(220, 218, 220))
                .scale(PxScale::from(w / BR)).font("JM") };

        let text = Text::new(frag);
        let td = text.dimensions(ctx);
        let pos = Vec2::new((w - td.w )/ 2.0, h / (TR * 0.85));
        canvas.draw(&text, pos);

        let message = if self.time.is_some() { "Space to resume\n Escape to leave" }
        else { "        Space to start\nTab to change keyboard" };
        let frag = TextFragment::new(message)
            .color(Color::from_rgb(220, 220, 220))
            .scale(PxScale::from(w / DBR)).font("JM");
        let text = Text::new(frag);
        let td = text.dimensions(ctx);
        let pos = Vec2::new((w - td.w) / 2.0, h * 0.8);
        canvas.draw(&text, pos);
    }
}

struct GameState {
    menu: GameMenu,
    virtual_keyboard: VirtualKeyboard,
    in_menu: bool,
    letters: String,
    tile_meshes: Vec<Mesh>,
    new_input: bool,
    solution: String,
    times: [f32; 6],
    time: f32,
}

impl GameState {
    const FPS: u32 = 120;

    fn tile_mesh(ctx: &mut Context, x: f32, y: f32, color: Color) -> Mesh {
        let (w, h) = ctx.gfx.drawable_size();
        let start_x = w / 2.0 - w/TR * 2.5;
        let start_y = h / 2.0 - w/TR * 3.0;

        let tile_rect = Rect::new(
            start_x + x * w/TR,
            start_y + y * w/TR,
            w/TR * 0.95, w/TR * 0.95);

        Mesh::new_rounded_rectangle(
            ctx, DrawMode::fill(), tile_rect, w/TR / 5.0, color)
            .unwrap()
    }

    fn new(ctx: &mut Context) -> Self {
        let font_data = FontData::from_path(ctx, "/JuanMikes.otf").unwrap();
        ctx.gfx.add_font("JM", font_data);
        
        let mut tile_meshes = Vec::new();
        for y in 0..6 { for x in 0..5 {
                tile_meshes.push(Self::tile_mesh(
                    ctx, x as f32, y as f32, Color::from_rgb(44, 44, 58))); } }
        let time = 0f32;
        let times = [time; 6];
        let solution = String::new();
        let menu = GameMenu::new(ctx);
        let virtual_keyboard = VirtualKeyboard::new();
        let mut state = Self {
            letters: String::new(), new_input: true, in_menu: true,
            time, tile_meshes, solution, times, menu, virtual_keyboard };
        state.set_random_solution();
        state
    }

    fn set_random_solution(&mut self) {
        self.solution = SOLUTIONS[random_range(0..SOLUTIONS.len())].to_owned();
    }

    fn guessed(&mut self, ctx: &mut Context) {
        self.new_input = true;
        let y = self.letters.len() / 5;
        if self.letters.len() % 5 == 0 {
            if y > 0 && self.times[y - 1] == 0.0 { self.times[y - 1] = self.time; } }

        let guess = &self.letters.chars().map(|x| x.to_lowercase().next().unwrap())
            .collect::<Vec<_>>()[(y - 1) * 5..y * 5];
        let sol_chars = self.solution.chars().collect::<Vec<_>>();
        let mut matched = vec![false; 5];
        for x in 0..5 {
            let char = guess[x];
            if char == sol_chars[x] {
                matched[x] = true;
                self.tile_meshes[(y - 1) * 5 + x] = Self::tile_mesh(
                    ctx, x as f32, y as f32 - 1.0, Color::from_rgb(0, 200, 20));
                self.virtual_keyboard.found_letters.push(char);
            } }

        for x in 0..5 {
            if guess[x] != sol_chars[x] {
                let mut found = false;
                for (j, &sol_c) in sol_chars.iter().enumerate() {
                    if !matched[j] && sol_c == guess[x] {
                        self.virtual_keyboard.correct_letters.push(guess[x]);
                        matched[j] = true; found = true; break; } }
                if !found { self.virtual_keyboard.wrong_letters.push(guess[x]); }
                let color = if found { Color::from_rgb(255, 150, 20) }
                else { Color::from_rgb(5, 7, 12) };
                self.tile_meshes[(y - 1) * 5 + x] =
                    Self::tile_mesh(ctx, x as f32, y as f32 - 1.0, color);
            } }
    }
}

impl EventHandler for GameState {
    fn update(&mut self, ctx: &mut Context) -> GameResult {
        while ctx.time.check_update_time(Self::FPS) {
            if self.in_menu {

            }
            else {
                if self.new_input {
                    let y = self.letters.len() / 5;
                    if y > 0 {
                        let last_guess = &self.letters.chars().collect::<Vec<_>>()[(y - 1) * 5..y * 5];
                        let sol_chars = self.solution.chars().collect::<Vec<_>>();
                        if last_guess == sol_chars {
                            self.in_menu = true;
                            self.menu.win = Some(true);
                            self.menu.time = Some(self.time);
                        } } }
                self.time += ctx.time.delta().as_secs_f32();
                self.menu.time = Some(self.time);
                if self.letters.len() == 30 && self.new_input && !self.in_menu {
                    self.in_menu = true;
                    self.menu.win = Some(false);
                } } }

        Ok(())
    }

    fn draw(&mut self, ctx: &mut Context) -> GameResult {
        let mut canvas = Canvas::from_frame(ctx, Color::from_rgb(22, 22, 29));
        self.virtual_keyboard.draw(&mut canvas, ctx);

        let (w, h) = ctx.gfx.drawable_size();
        let start_x = w / 2.0 - w/TR * 2.5;
        let start_y = h / 2.0 - w/TR * 3.0;
        for mesh in &self.tile_meshes { canvas.draw(mesh, Vec2::ZERO); }

        for (i, ch) in self.letters.chars().enumerate() {
            let x = start_x + ((i % 5) as f32 * w / TR);
            let y = start_y + ((i / 5) as f32 * w / TR);

            let text_fragment = TextFragment::new(ch.to_string().to_uppercase())
                .color(Color::from_rgb(245, 240, 242))
                .scale(PxScale::from(w / TR * 0.75)).font("JM");
            let text = Text::new(text_fragment);

            let text_dimensions = text.dimensions(ctx);
            let text_x = x + (w / TR - text_dimensions.w) / 2.0;
            let text_y = y + (w / TR - text_dimensions.h) / 2.0;
            canvas.draw(&text, Vec2::new(text_x, text_y));

            if i % 5 == 4 {
                let row = i / 5;
                let time = if row == 0 { self.times[0] }
                else { self.times[row] - self.times[row - 1] };
                if time > 0.0 {
                    let time_fragment = TextFragment::new(format!("{:.1}", time))
                        .color(Color::from_rgb(245, 240, 242))
                        .scale(PxScale::from(w / TR * 0.5)).font("JM");
                    let time_text = Text::new(time_fragment);
                    canvas.draw(
                        &time_text, Vec2::new(start_x + w / TR * 5.0, text_y));
                } } }

        if self.in_menu { self.menu.draw(&mut canvas, ctx, self.solution.clone()); }
        canvas.finish(ctx)
    }

    fn key_down_event(&mut self, ctx: &mut Context, input: KeyInput, _: bool) -> GameResult {
        let char = input.event.logical_key.to_text();
        if input.event.logical_key == Key::Named(NamedKey::Space) && self.in_menu {
            let layout = self.virtual_keyboard.layout.clone();
            *self = GameState::new(ctx); self.in_menu = false; self.virtual_keyboard.layout = layout; }
        else if input.event.logical_key == Key::Named(NamedKey::Space) && !self.in_menu { self.in_menu = true; }
        else if input.event.logical_key == Key::Named(NamedKey::Tab) { self.virtual_keyboard.swap_layout() }
        else if input.event.logical_key == Key::Named(NamedKey::Escape) { ctx.request_quit(); }
        else if input.event.logical_key == Key::Named(NamedKey::Enter) {
            let y = self.letters.len() / 5;
            if y > 0 {
                let guess = self.letters.clone().split_off((y - 1) * 5);
                if VALID_GUESSES.iter().any(|&x| x == guess.as_str()) {
                    self.guessed(ctx); } } }
        else if input.event.logical_key == Key::Named(NamedKey::Backspace) {
            if !(self.letters.len() % 5 == 0 && self.new_input) { self.letters.pop(); }
            if self.letters.len() % 5 == 0 { self.new_input = true; } }
        else if char.is_some() && !self.in_menu {
            if self.new_input || self.letters.len() % 5 != 0 {
                self.letters.push(char.unwrap().chars().next().unwrap());
                self.new_input = false; } }
        Ok(())
    }
}

pub fn main() -> GameResult {
    let (mut ctx, events_loop) = ContextBuilder::new("", "")
        .window_setup(WindowSetup::default().title(""))
        .window_mode(WindowMode::default().fullscreen_type(FullscreenType::Desktop)).build()?;

    let state = GameState::new(&mut ctx);
    event::run(ctx, events_loop, state)
}