use ggez::{event, Context, ContextBuilder, GameResult};
use ggez::conf::{FullscreenType, WindowMode, WindowSetup};
use ggez::event::EventHandler;
use ggez::glam::Vec2;
use ggez::graphics::{Canvas, Color, Drawable, FontData, Mesh, PxScale, Rect, Text, TextFragment};
use ggez::input::keyboard::{Key, KeyInput};
use ggez::winit::keyboard::NamedKey;
use lazy_static::lazy_static;
use rand::{random_range};

lazy_static! {
    static ref VALID_GUESSES: Vec<&'static str> = {
        include_str!("valid_guesses.txt")
            .lines().map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .collect() };
    static ref SOLUTIONS: Vec<&'static str> = {
        include_str!("solutions.txt")
            .lines().map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .collect() };
}

struct VirtualKeyboard {
    found_letters: String,
    correct_letters: String,
    wrong_letters: String,
}

impl VirtualKeyboard {
    fn new() -> Self {
        Self { found_letters: String::new(),
               correct_letters: String::new(),
               wrong_letters: String::new() }
    }

    fn draw(&self, canvas: &mut Canvas, ctx: &mut Context) {
        let (w, h) = ctx.gfx.drawable_size();
        let columns = ["abcdefghijklm", "nopqrstuvwxyz"];

        columns.iter().enumerate().for_each(|(i, letters)| {
            (0..letters.len()).for_each(|row| {
                let char = letters.chars().nth(row).unwrap();
                let letter_fragment = TextFragment::new(char.to_uppercase().to_string())
                    .color(if self.found_letters.contains(char) { Color::from_rgb(0, 200, 20) }
                    else if self.correct_letters.contains(char) { Color::from_rgb(255, 150, 20) }
                    else if self.wrong_letters.contains(char) { Color::from_rgb(22, 22, 29) }
                    else { Color::from_rgb(245, 240, 242) })
                    .scale(PxScale::from(w / 20.0)).font("JM");
                let letter = Text::new(letter_fragment);

                let y = row as f32 * (h / 13.0);
                canvas.draw(&letter, Vec2::new(i as f32 * (h / 20.0), y));
            }); });
    }
}

struct GameMenu {
    floating: Mesh,
    floating_stroke: Mesh,
    time: Option<f32>,
    win: Option<bool>,
}

impl GameMenu {
    fn new(ctx: &mut Context) -> Self {
        let (w, h) = ctx.gfx.drawable_size();

        let rect = Rect::new(w / 6.0, h / 20.0, w / 1.5, h / 10.0);
        let floating = Mesh::new_rounded_rectangle(
            ctx, ggez::graphics::DrawMode::fill(), rect, w / 40.0,
            Color::from_rgb(5, 7, 15)).unwrap();
        let floating_stroke = Mesh::new_rounded_rectangle(
            ctx, ggez::graphics::DrawMode::stroke(w / 120.0),
            rect, w / 40.0, Color::from_rgb(10, 7, 15)).unwrap();

        Self { floating, floating_stroke, time: None, win: None, }
    }

    fn draw(&self, canvas: &mut Canvas, ctx: &mut Context, solution: String) {
        let (w, h) = ctx.gfx.drawable_size();
        canvas.draw(&self.floating, Vec2::ZERO);
        canvas.draw(&self.floating_stroke, Vec2::ZERO);
        let status_text = if let Some(win) = self.win {
            if win { &format!("You Won in {:.2}", self.time.unwrap()) } else { &solution } }
            else { "Welcome! I AM IN YOUR WALLS" };
        let frag = if let Some(win) = self.win {
                TextFragment::new(status_text)
                    .color(if win { Color::from_rgb(120, 250, 120) }
                    else { Color::from_rgb(220, 10, 20) })
                    .scale(PxScale::from(w / 20.0)).font("JM") }
            else { TextFragment::new(status_text)
                .color(Color::from_rgb(220, 218, 220))
                .scale(PxScale::from(w / 20.0)).font("JM") };

        let text = Text::new(frag);
        let td = text.dimensions(ctx);
        let pos = Vec2::new((w - td.w )/ 2.0, h / 18.0);
        canvas.draw(&text, pos);

        let message = if self.time.is_some() { "Space to play" } else { "Space to start" };
        let frag = TextFragment::new(message)
            .color(Color::from_rgb(220, 220, 220))
            .scale(PxScale::from(w / 30.0)).font("JM");
        let text = Text::new(frag);
        let td = text.dimensions(ctx);
        let pos = Vec2::new((w - td.w) / 2.0, h * 0.8);
        canvas.draw(&text, pos);
    }
}

struct GameState {
    menu: GameMenu,
    virtual_keyboard: VirtualKeyboard,
    in_menu: bool,
    letters: String,
    tile_meshes: Vec<Mesh>,
    new_input: bool,
    solution: String,
    times: [f32; 6],
    time: f32,
}

impl GameState {
    const TILE_SIZE: f32 = 100.0;
    const FPS: u32 = 120;

    fn tile_mesh(ctx: &mut Context, x: f32, y: f32, color: Color) -> Mesh {
        let (w, h) = ctx.gfx.drawable_size();
        let start_x = w / 2.0 - Self::TILE_SIZE * 2.5;
        let start_y = h / 2.0 - Self::TILE_SIZE * 3.0;

        let tile_rect = Rect::new(
            start_x + x * Self::TILE_SIZE,
            start_y + y * Self::TILE_SIZE,
            Self::TILE_SIZE * 0.95, Self::TILE_SIZE * 0.95);

        Mesh::new_rounded_rectangle(
            ctx, ggez::graphics::DrawMode::fill(), tile_rect, Self::TILE_SIZE / 5.0, color)
            .unwrap()
    }

    fn new(ctx: &mut Context) -> Self {
        let font_data = FontData::from_path(ctx, "/JuanMikes.otf").unwrap();
        ctx.gfx.add_font("JM", font_data);
        
        let mut tile_meshes = Vec::new();
        for y in 0..6 { for x in 0..5 {
                tile_meshes.push(Self::tile_mesh(
                    ctx, x as f32, y as f32, Color::from_rgb(44, 44, 58))); } }
        let time = 0f32;
        let times = [time; 6];
        let solution = "guess".to_owned();
        let menu = GameMenu::new(ctx);
        let virtual_keyboard = VirtualKeyboard::new();
        let mut state = Self {
            letters: String::new(), new_input: true, in_menu: true,
            time, tile_meshes, solution, times, menu, virtual_keyboard };
        state.set_random_solution();
        state
    }

    fn set_random_solution(&mut self) {
        self.solution = SOLUTIONS[random_range(0..SOLUTIONS.len())].to_owned();
    }

    fn guessed(&mut self, ctx: &mut Context) {
        self.new_input = true;
        let y = self.letters.len() / 5;
        if self.letters.len() % 5 == 0 {
            if y > 0 && self.times[y - 1] == 0.0 { self.times[y - 1] = self.time; } }

        let guess = &self.letters.chars().map(|x| x.to_lowercase().next().unwrap())
            .collect::<Vec<_>>()[(y - 1) * 5..y * 5];
        let sol_chars = self.solution.chars().collect::<Vec<_>>();
        let mut matched = vec![false; 5];
        for x in 0..5 {
            let char = guess[x];
            if char == sol_chars[x] {
                matched[x] = true;
                self.tile_meshes[(y - 1) * 5 + x] = Self::tile_mesh(
                    ctx, x as f32, y as f32 - 1.0, Color::from_rgb(0, 200, 20));
                self.virtual_keyboard.found_letters.push(char);
            } }

        for x in 0..5 {
            if guess[x] != sol_chars[x] {
                let mut found = false;
                for (j, &sol_c) in sol_chars.iter().enumerate() {
                    if !matched[j] && sol_c == guess[x] {
                        self.virtual_keyboard.correct_letters.push(guess[x]);
                        matched[j] = true; found = true; break; } }
                if !found { self.virtual_keyboard.wrong_letters.push(guess[x]); }
                let color = if found { Color::from_rgb(255, 150, 20) }
                else { Color::from_rgb(5, 7, 12) };
                self.tile_meshes[(y - 1) * 5 + x] =
                    Self::tile_mesh(ctx, x as f32, y as f32 - 1.0, color);
            } }
    }
}

impl EventHandler for GameState {
    fn update(&mut self, ctx: &mut Context) -> GameResult {
        while ctx.time.check_update_time(Self::FPS) {
            if self.in_menu {

            }
            else {
                if self.new_input {
                    let y = self.letters.len() / 5;
                    if y > 0 {
                        let last_guess = &self.letters.chars().collect::<Vec<_>>()[(y - 1) * 5..y * 5];
                        let sol_chars = self.solution.chars().collect::<Vec<_>>();
                        if last_guess == sol_chars {
                            self.in_menu = true;
                            self.menu.win = Some(true);
                            self.menu.time = Some(self.time);
                        } } }
                self.time += ctx.time.delta().as_secs_f32();
                if self.letters.len() == 30 && self.new_input && !self.in_menu {
                    self.in_menu = true;
                    self.menu.win = Some(false);
                } } }

        Ok(())
    }

    fn draw(&mut self, ctx: &mut Context) -> GameResult {
        let mut canvas = Canvas::from_frame(ctx, Color::from_rgb(22, 22, 29));

        let (w, h) = ctx.gfx.drawable_size();
        let start_x = w / 2.0 - Self::TILE_SIZE * 2.5;
        let start_y = h / 2.0 - Self::TILE_SIZE * 3.0;
        for mesh in &self.tile_meshes { canvas.draw(mesh, Vec2::ZERO); }

        for (i, ch) in self.letters.chars().enumerate() {
            let x = start_x + ((i % 5) as f32 * Self::TILE_SIZE);
            let y = start_y + ((i / 5) as f32 * Self::TILE_SIZE);

            let text_fragment = TextFragment::new(ch.to_string().to_uppercase())
                .color(Color::from_rgb(245, 240, 242))
                .scale(PxScale::from(Self::TILE_SIZE * 0.7)).font("JM");
            let text = Text::new(text_fragment);

            let text_dimensions = text.dimensions(ctx);
            let text_x = x + (Self::TILE_SIZE - text_dimensions.w) / 2.0;
            let text_y = y + (Self::TILE_SIZE - text_dimensions.h) / 2.0;
            canvas.draw(&text, Vec2::new(text_x, text_y));

            if i % 5 == 4 {
                let row = i / 5;
                let time = if row == 0 { self.times[0] }
                else { self.times[row] - self.times[row - 1] };
                if time > 0.0 {
                    let time_fragment = TextFragment::new(format!("{:.1}", time))
                        .color(Color::from_rgb(245, 240, 242))
                        .scale(PxScale::from(Self::TILE_SIZE * 0.7)).font("JM");
                    let time_text = Text::new(time_fragment);
                    canvas.draw(
                        &time_text, Vec2::new(start_x + Self::TILE_SIZE * 6.0, text_y));
                } } }

        if self.in_menu { self.menu.draw(&mut canvas, ctx, self.solution.clone()); }
        self.virtual_keyboard.draw(&mut canvas, ctx);
        canvas.finish(ctx)
    }

    fn key_down_event(&mut self, ctx: &mut Context, input: KeyInput, _: bool) -> GameResult {
        let char = input.event.logical_key.to_text();
        if input.event.logical_key == Key::Named(NamedKey::Space) && self.in_menu {
            *self = GameState::new(ctx);
            self.in_menu = false;
        }
        else if input.event.logical_key == Key::Named(NamedKey::Escape) { ctx.request_quit(); }
        else if input.event.logical_key == Key::Named(NamedKey::Enter) {
            let y = self.letters.len() / 5;
            if y > 0 {
                let guess = self.letters.clone().split_off((y - 1) * 5);
                if VALID_GUESSES.iter().any(|&x| x == guess.as_str()) {
                    self.guessed(ctx); } } }
        else if input.event.logical_key == Key::Named(NamedKey::Backspace) {
            if !(self.letters.len() % 5 == 0 && self.new_input) { self.letters.pop(); }
            if self.letters.len() % 5 == 0 { self.new_input = true; } }
        else if char.is_some() && !self.in_menu {
            if self.new_input || self.letters.len() % 5 != 0 {
                self.letters.push(char.unwrap().chars().next().unwrap());
                self.new_input = false; } }
        Ok(())
    }
}

pub fn main() -> GameResult {
    let (mut ctx, events_loop) = ContextBuilder::new("", "")
        .window_setup(WindowSetup::default().title(""))
        .window_mode(WindowMode::default().fullscreen_type(FullscreenType::Desktop)).build()?;

    let state = GameState::new(&mut ctx);
    event::run(ctx, events_loop, state)
}